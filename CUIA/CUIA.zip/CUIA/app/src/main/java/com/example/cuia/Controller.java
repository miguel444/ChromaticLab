package com.example.cuia;

public class Controller {

    public static int default_value_daltonismo=0;
    public static int default_value_dicromatismo = 0;
    public static int default_value_monocromatismo = 0;
    public static String info_daltonismo ="ACROMÁTICO";
    public static int idioma = 0;
}
